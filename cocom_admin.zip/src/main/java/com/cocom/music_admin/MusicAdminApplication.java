package com.cocom.music_admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MusicAdminApplication {

	public static void main(String[] args) {
		SpringApplication.run(MusicAdminApplication.class, args);
	}

}
