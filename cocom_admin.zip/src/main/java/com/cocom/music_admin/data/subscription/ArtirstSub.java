package com.cocom.music_admin.data.subscription;

import lombok.Data;

@Data
public class ArtirstSub {
    private Integer as_seq;
    private Integer as_ai_seq;
    private Integer as_mi_seq;
}
