package com.cocom.music_admin.data.basic;

import lombok.Data;

@Data
public class GenreInfo {
    private Integer gr_seq;
    private String gr_name;
}
