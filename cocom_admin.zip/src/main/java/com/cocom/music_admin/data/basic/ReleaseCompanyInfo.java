package com.cocom.music_admin.data.basic;

import lombok.Data;

@Data
public class ReleaseCompanyInfo {
    private Integer rci_seq;
    private String rci_name;
}
