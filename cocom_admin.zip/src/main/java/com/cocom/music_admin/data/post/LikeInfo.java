package com.cocom.music_admin.data.post;

import lombok.Data;

@Data
public class LikeInfo {
    private Integer li_seq;
    private Integer li_mi_seq;
    private Integer li_ai_seq;
    private Integer li_mu_seq;
    private Integer li_ab_seq;
    private Integer li_ent_seq;
    private Integer li_acom_seq;
    private Integer li_mcom_seq;
    private Integer li_mzcom_seq;
    private Integer li_ci_seq;
    private Integer li_spi_seq;
}
