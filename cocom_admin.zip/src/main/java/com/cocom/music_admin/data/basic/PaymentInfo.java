package com.cocom.music_admin.data.basic;

import lombok.Data;

@Data
public class PaymentInfo {
    private Integer pi_seq;
    private Integer pi_mi_seq;
    private Integer pi_gz_seq;
    private Integer pi_tic_seq;
    private Integer pi_ps_seq;
}
