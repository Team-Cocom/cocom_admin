package com.cocom.music_admin.data.business;

import lombok.Data;

@Data
public class StarpostDescriptionInfo {
    private Integer sdec_seq;
    private Integer sdec_spi_seq;
    private String sdec_text;
    private String sdec_img_file;
    private Integer sdec_order;
    private Integer sdec_ai_seq;
    private Integer sdec_scom_seq;
}
