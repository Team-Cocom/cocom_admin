package com.cocom.music_admin.data.basic;

import lombok.Data;

@Data
public class EnterInfo {
    private Integer ent_seq;
    private String ent_name;
}
