package com.cocom.music_admin.data.basic;

import lombok.Data;

@Data
public class CountryInfo {
    private Integer cr_seq;
    private String cr_name;
}
