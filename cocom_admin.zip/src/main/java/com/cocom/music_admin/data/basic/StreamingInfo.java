package com.cocom.music_admin.data.basic;

import lombok.Data;

@Data
public class StreamingInfo {
    private Integer str_seq;
    private Integer str_mu_seq;
    private Integer str_mv_seq;
    private Integer str_mi_seq;
    private Integer str_playtime;
}
