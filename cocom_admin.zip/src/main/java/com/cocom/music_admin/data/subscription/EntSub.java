package com.cocom.music_admin.data.subscription;

import lombok.Data;

@Data
public class EntSub {
    private Integer es_seq;
    private Integer es_ent_seq;
    private Integer es_mi_seq;
}
