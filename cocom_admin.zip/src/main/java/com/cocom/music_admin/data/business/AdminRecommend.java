package com.cocom.music_admin.data.business;

import lombok.Data;

@Data
public class AdminRecommend {
    private Integer ard_seq;
    private Integer ard_aa_seq;
    private Integer ard_mu_seq;
    private String ard_title;
    private Integer ard_ab_seq;
}
