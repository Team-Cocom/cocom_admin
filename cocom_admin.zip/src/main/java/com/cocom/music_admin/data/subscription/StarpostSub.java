package com.cocom.music_admin.data.subscription;

import lombok.Data;

@Data
public class StarpostSub {
    private Integer ss_seq;
    private Integer ss_spi_seq;
    private Integer ss_mi_seq;
}
