package com.cocom.music_admin.data.business;

import lombok.Data;

@Data
public class PassInfo {
    private Integer ps_seq;
    private Integer ps_type;
    private Integer ps_period;
}
