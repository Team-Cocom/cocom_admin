package com.cocom.music_admin.data.basic;

import lombok.Data;

@Data
public class PlaylistInfo {
    private Integer pls_seq;
    private Integer pls_mi_seq;
    private Integer pls_mu_seq;
    private Integer pls_open;
    private Integer pls_li_seq;
}
